export '../domain/result.dart';
